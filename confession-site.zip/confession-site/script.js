// script.js - Confession site (anonymous + public)
// IMPORTANT: create a Firebase project and Firestore database, then paste your config below.
// Steps (quick):
// 1. Go to https://console.firebase.google.com/ -> Create Project.
// 2. In Project settings -> Add web app -> copy the config and paste into `firebaseConfig` below.
// 3. In Firestore Database -> Create a database (start in production or test mode as you prefer).
// 4. Deploy this folder to GitHub Pages (push to a repo and enable Pages).
// NOTE: This site intentionally allows any words. Be responsible about public access.

// --------- Paste your Firebase config here ----------
const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_AUTH_DOMAIN",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_STORAGE_BUCKET",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};
// ----------------------------------------------------

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const confCol = db.collection('confessions');

// DOM
const postBtn = document.getElementById('postBtn');
const confInput = document.getElementById('confession');
const confList = document.getElementById('confessions');
const status = document.getElementById('status');

// Post confession
postBtn.addEventListener('click', async () => {
  const text = (confInput.value || '').trim();
  if (!text) { status.textContent = 'Write something first.'; return; }
  postBtn.disabled = true;
  status.textContent = 'Posting...';
  try {
    await confCol.add({
      text,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    confInput.value = '';
    status.textContent = 'Posted ✓';
    setTimeout(()=>status.textContent='',1200);
  } catch (e) {
    console.error(e);
    status.textContent = 'Error posting. Check Firestore rules & config.';
  } finally {
    postBtn.disabled = false;
  }
});

// Render a confession element
function renderConf(doc){
  const el = document.createElement('div');
  el.className = 'confession';
  const when = doc.createdAt ? new Date(doc.createdAt.seconds*1000).toLocaleString() : '';
  el.innerHTML = `<div style="white-space:pre-wrap">${escapeHtml(doc.text)}</div><div style="margin-top:8px;font-size:12px;color:#9aa8b0">${when}</div>`;
  return el;
}

// Escape HTML to avoid XSS (we still allow all words but escape HTML tags)
function escapeHtml(s){
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// Live updates: listen to latest 200 confessions ordered by createdAt desc
confCol.orderBy('createdAt','desc').limit(200).onSnapshot(snap => {
  confList.innerHTML = '';
  snap.forEach(d => {
    const data = d.data();
    // Firestore serverTimestamp may be null for very recent writes; also attach id
    confList.appendChild(renderConf(data));
  });
});
