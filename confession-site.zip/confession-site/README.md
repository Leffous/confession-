Confess•Share — Anonymous public confession site (GitHub Pages)

What this is
------------
A single-page static site that lets anyone anonymously post and read confessions. It's GitHub Pages–ready (static frontend) and uses Firebase Firestore to store confessions.

Important notes
---------------
- **Anonymous & public**: Anyone can read and post if they have the page URL and you configure Firestore rules to allow reads/writes.
- **No word filters**: The site intentionally allows any words. Posts are escaped to prevent HTML/XSS but otherwise uncensored.
- **Be responsible**: Public posting may allow abusive content. Keep moderators or enable reporting if needed.

Setup (quick)
-------------
1. Create a Firebase project at https://console.firebase.google.com/.
2. Add a Web App in Project Settings and copy the config (apiKey, projectId, etc.).
3. Enable Firestore Database in your project (create in production or test mode).
4. Paste your Firebase config into `script.js` at the firebaseConfig variable.
5. (Optional) Adjust Firestore rules for public read/write. Example test rules (OPEN — not secure):
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /{document=**} {
         allow read, write: if true;
       }
     }
   }
   ```
   **Warning**: The above rules allow anyone with your project ID to write/read. Use only for private groups.

Deploy to GitHub Pages
---------------------
1. Create a new GitHub repository and push these files to the `main` branch.
2. In the repository Settings → Pages, set the source to `main` branch and root (`/`).
3. GitHub will provide a URL like https://<username>.github.io/<repo>/

That's it — share the URL with your friends.

Security & moderation suggestions
--------------------------------
- If the project becomes popular, tighten Firestore rules or require a simple passphrase field on post submissions.
- Provide a reporting email or mechanism (you can record reports in a Firestore collection).
- Periodically export and back up the Firestore collection for safety.
